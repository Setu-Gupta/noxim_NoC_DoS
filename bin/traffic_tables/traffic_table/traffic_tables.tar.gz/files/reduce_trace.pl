#!/usr/bin/perl
use warnings;
use strict;
 
my $filename = 'lud_traces_64_Network_File.txt';
 
open(FH, '<', $filename) or die $!;
 
while(<FH>){
   $_=~/(\d+)\s+(\d+)\s+.*$/;
   print "$1 $2\n";
}
 
close(FH);




#sed -i "/GPU/d" backprop_traces_64_Network_File.txt
