# Use this when you have trace file

$stuff = "backprop_traces_64_Network_File.txt";
#$stuff = "gaussian_traces_64_Network_File.txt";
#$stuff = "lud_traces_64_Network_File.txt";
#$stuff = "kmeans_traces_64_Network_File.txt";
#$stuff = "hotspot_traces_64_Network_File.txt";
#$stuff = "mummergpu_traces_64_Network_File.txt";

open STUFF, $stuff;

@sourceArray;
#@destArray;

while (<STUFF>) {
	my ($src,$dest) = $_ =~ m{^(\d+)\s(\d+)\s};
	$sourceArray[$src][$dest] += 1;
	#$sourceArray[$src] += 1;
	#$destArray[$dest]=$destArray[$dest]+1;
}

#@n=(0..63);
#foreach (@n) {
#	print "$_ node: $sourceArray[$_] \t\t $destArray[$_]\n";
#}

for( $n = 0; $n < 64; $n = $n + 1 ) {
	for( $m = 0; $m < 64; $m = $m + 1 ) {

		if($sourceArray[$n][$m]){
			print "($n:$m) $sourceArray[$n][$m]\t";
			if($m%7 == 0){print "\n";}
		}

	}
   print "\n";
}

