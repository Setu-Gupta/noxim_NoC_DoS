# Use this to find number of token passes
#	grep -rin "*** Token of channel 0 has been assigned to Hub" normal_16x16_transpose2_log.txt > dump.txt


# Use this when you have the log file

$stuff = "/home/suyog/noxim/log_files/normal_16x16_butterfly_log.txt";
#$stuff = "butterfly_log.txt";
#$stuff = "shuffle_log.txt";
#$stuff = "TT1_log.txt";
#$stuff = "TT2_log.txt";
#$stuff = "random_log.txt";

open STUFF, $stuff;

my @sourceArray;
my @destArray;

while (<STUFF>) {

	#find this line->    Consumed flit (H0, 58->52 VC 0)
	if (my ($src,$dest) = $_ =~ m{Consumed\sflit\s\(H0,\s(\d+)->(\d+)\sVC\s0\)}) {
	$sourceArray[$src][$dest] += 1;
	#$sourceArray[$src] = $sourceArray[$src]+1;
	#$destArray[$dest] = $destArray[$dest]+1;
	}
}

#print "@sourceArray";

#@n=(0..255);
#foreach (@n) {
#	print "$_ node: $sourceArray[$_] \t\t $destArray[$_]\n";
#}

for( $n = 0; $n < 256; $n = $n + 1 ) {
	for( $m = 0; $m < 256; $m = $m + 1 ) {

		if($sourceArray[$n][$m]){
			print "($n:$m) $sourceArray[$n][$m]\t";
			if($m%7 == 0){print "\n";}
		}

	}
   print "\n";
}
